﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Cryptography;
using System.Net.NetworkInformation;


namespace csharp_i2c_master
{
    internal class Program
    {
        //**************************************************************************
        //
        // FUNCTION IMPORTS FROM LIBFT4222 DLL
        //
        //**************************************************************************

        const String LibFT260Name="LibFT260.dll";
        [DllImport(LibFT260Name, CallingConvention = CallingConvention.StdCall)]
        public static extern FT260_STATUS FT260_GetChipVersion(IntPtr ft260Handle, ref UInt32 lpdwChipVersion);
        [DllImport(LibFT260Name, CallingConvention = CallingConvention.StdCall)]
        public static extern FT260_STATUS FT260_GetLibVersion(ref UInt32 lpdwLibVersion);
        [DllImport(LibFT260Name, CallingConvention = CallingConvention.StdCall)]
        public static extern FT260_STATUS FT260_CreateDeviceList(ref UInt32 lpdwNumDevs);
        [DllImport(LibFT260Name, CallingConvention = CallingConvention.StdCall)]
        public static extern FT260_STATUS FT260_GetDevicePath(out byte pDevicePath, UInt32 bufferLength, UInt32 deviceIndex);
        [DllImport(LibFT260Name, CallingConvention = CallingConvention.StdCall)]
        public static extern FT260_STATUS FT260_OpenByVidPid(UInt16 vid, UInt16 pid, UInt32 deviceIndex, ref IntPtr pFt260Handle);
        [DllImport(LibFT260Name, CallingConvention = CallingConvention.StdCall)]
        public static extern FT260_STATUS FT260_I2CMaster_Init(IntPtr ft260Handle, UInt32 kbps);
        [DllImport(LibFT260Name, CallingConvention = CallingConvention.StdCall)]
        public static extern FT260_STATUS FT260_I2CMaster_Read(IntPtr handle, byte deviceAddress, FT260_I2C_FLAG flag, ref byte lpBuffer, UInt32 dwBytesToRead, ref UInt32 lpdwBytesReturned, UInt32 wait_timer = 5000);
        [DllImport(LibFT260Name, CallingConvention = CallingConvention.StdCall)]
        public static extern FT260_STATUS FT260_I2CMaster_Write(IntPtr ft260Handle, byte deviceAddress, FT260_I2C_FLAG flag, ref byte lpBuffer, UInt32 dwBytesToWrite, ref UInt32 lpdwBytesWritten);
        [DllImport(LibFT260Name, CallingConvention = CallingConvention.StdCall)]
        public static extern FT260_STATUS FT260_I2CMaster_Reset(IntPtr ft260Handle);
        [DllImport(LibFT260Name, CallingConvention = CallingConvention.StdCall)]
        public static extern FT260_STATUS FT260_I2CMaster_GetStatus(IntPtr ft260Handle, ref byte status);
        [DllImport(LibFT260Name, CallingConvention = CallingConvention.StdCall)]
        public static extern FT260_STATUS FT260_I2CMaster_ReadAndMonitorStatus(IntPtr handle, byte deviceAddress, FT260_I2C_FLAG flag, ref byte lpBuffer, UInt32 dwBytesToRead, ref UInt32 lpdwBytesReturned, ref byte status, UInt32 wait_timer = 5000);
        [DllImport(LibFT260Name, CallingConvention = CallingConvention.StdCall)]
        public static extern FT260_STATUS FT260_I2CMaster_WriteAndMonitorStatus(IntPtr ft260Handle, byte deviceAddress, FT260_I2C_FLAG flag, ref byte lpBuffer, UInt32 dwBytesToWrite, ref UInt32 lpdwBytesWritten, ref byte status);

        public enum FT260_STATUS
        {
            FT260_OK,
            FT260_INVALID_HANDLE,
            FT260_DEVICE_NOT_FOUND,
            FT260_DEVICE_NOT_OPENED,
            FT260_DEVICE_OPEN_FAIL,
            FT260_DEVICE_CLOSE_FAIL,
            FT260_INCORRECT_INTERFACE,
            FT260_INCORRECT_CHIP_MODE,
            FT260_DEVICE_MANAGER_ERROR,
            FT260_IO_ERROR,
            FT260_INVALID_PARAMETER,
            FT260_NULL_BUFFER_POINTER,
            FT260_BUFFER_SIZE_ERROR,
            FT260_UART_SET_FAIL,
            FT260_RX_NO_DATA,
            FT260_GPIO_WRONG_DIRECTION,
            FT260_INVALID_DEVICE,
            FT260_INVALID_OPEN_DRAIN_SET,
            FT260_INVALID_OPEN_DRAIN_RESET,
            FT260_I2C_READ_FAIL,
            FT260_OTHER_ERROR
        };

        public enum FT260_I2C_FLAG
        {
            FT260_I2C_NONE = 0,
            FT260_I2C_START = 0x02,
            FT260_I2C_REPEATED_START = 0x03,
            FT260_I2C_STOP = 0x04,
            FT260_I2C_START_AND_STOP = 0x06
        };

        static void ListAllDevicePaths()
        {
            UInt32 devNum = 0;
            byte[] pathBuf = new byte[256]; //path is WCHAR

            FT260_CreateDeviceList(ref devNum);

            for (UInt32 i = 0; i < devNum; i++)
            {
                FT260_GetDevicePath(out pathBuf[0], 256, i);
                string strR = System.Text.Encoding.Unicode.GetString(pathBuf);
                Console.WriteLine("Index:{0}, Path:{1}", i, strR);
            }
        }

        static void PrintI2CStatus(byte status)
        {
            Console.WriteLine($"I2C Status: 0x{status:X2}");

            bool hasStatus = false;

            if (((status) & 0x01) != 0)
            {
                Console.WriteLine("- Controller is busy");
                hasStatus = true;
            }
            if (((status) & 0x02) != 0)
            {
                Console.WriteLine("- Error condition");
                hasStatus = true;
            }
            if (((status) & 0x04) != 0)
            {
                Console.WriteLine("- Address not acknowledged (NACK)");
                hasStatus = true;
            }
            if (((status) & 0x08) != 0)
            {
                Console.WriteLine("- Data not acknowledged (NACK)");
                hasStatus = true;
            }
            if (((status) & 0x10) != 0)
            {
                Console.WriteLine("- Arbitration lost");
                hasStatus = true;
            }
            if (((status) & 0x20) != 0)
            {
                Console.WriteLine("- Controller is idle");
                hasStatus = true;
            }
            if (((status) & 0x40) != 0)
            {
                Console.WriteLine("- Bus is busy");
                hasStatus = true;
            }
            if (!hasStatus)
            {
                Console.WriteLine("- No known status flags set");
            }
        }
		
        static void TestGetStart(IntPtr ft260Handle)
        {
            FT260_STATUS ftStatus = FT260_STATUS.FT260_OTHER_ERROR;
            // Show version information
            UInt32 dwChipVersion = 0;
            UInt32 MASK_1 = 0xff;
            ftStatus = FT260_GetChipVersion(ft260Handle, ref dwChipVersion);
            if (FT260_STATUS.FT260_OK != ftStatus)
            {
                Console.WriteLine("Get chip version Failed, status: {0}", ftStatus);
            }
            else
            {
                Console.WriteLine("Get chip version OK");

                Console.WriteLine("Chip version :{0:X2}.{1:X2}.{2:X2}.{3:X2}",
                    ((dwChipVersion >> 24) & MASK_1),
                    ((dwChipVersion >> 16) & MASK_1),
                    ((dwChipVersion >> 8) & MASK_1),
                    (dwChipVersion & MASK_1));
            }

            UInt32 dwLibVersion = 0;
            ftStatus = FT260_GetLibVersion(ref dwLibVersion);
            if (FT260_STATUS.FT260_OK != ftStatus)
            {
                Console.WriteLine("FT260_GetLibVersion Failed, status: {0}", ftStatus);
            }
            else
            {
                Console.WriteLine("FT260_GetLibVersion OK");
                Console.WriteLine("DLL version :{0:X}.{1:X}.{2:X}.{3:X}",
                    ((dwLibVersion >> 24) & MASK_1),
                    ((dwLibVersion >> 16) & MASK_1),
                    ((dwLibVersion >> 8) & MASK_1),
                    (dwLibVersion & MASK_1));
            }
        }

        static void TestI2C(IntPtr ft260Handle)
        {
            FT260_STATUS ftStatus = FT260_STATUS.FT260_OTHER_ERROR;
            ftStatus = FT260_I2CMaster_Init(ft260Handle, 400);
            byte I2CAddr = 0x22;
            while (true)
            {
                Console.WriteLine("I2C app (0)Set Addr(Hex) (1)Read (2)Write (3)Reset (4)Get status (5)Read EEPROM  (6)Quit>>>> ");
                string input = Console.ReadLine();

                if (input == "0")
                {
                    Console.WriteLine("please input new i2c address, original is 0x{0:X2}", I2CAddr);
                    string newi2cAddrStr = Console.ReadLine();
                    byte newi2cAddr;
                    if (newi2cAddrStr.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
                    {
                        newi2cAddrStr = newi2cAddrStr.Substring(2); // remove "0x"
                    }
                    if (byte.TryParse(newi2cAddrStr, System.Globalization.NumberStyles.HexNumber, null, out newi2cAddr))
                    {
                        I2CAddr = newi2cAddr;
                        Console.WriteLine("set i2cAddr = 0x{0:X2}", I2CAddr);
                    }
                    else
                    {
                        Console.WriteLine("Address format error, 0x00~0xFF or 00~FF");
                    }
                }
                else if (input == "1")
                {
                    Console.WriteLine("How many bytes do you want to read?");
                    Console.WriteLine("Enter an unsigned number: ");
                    string lenStr = Console.ReadLine();
                    byte len = 0;
                    UInt32 readLength = 0;
                    byte[] readData;
                    if (byte.TryParse(lenStr, System.Globalization.NumberStyles.Number, null, out len))
                    {
                        Console.WriteLine("set read length = {0}", len);
                        if ( (len < 1) || (len > 60))
                        {
                            Console.WriteLine("Length format error, 1~60");
                            continue;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Length format error, 1~60");
                        continue;
                    }
                    readData = new byte[len];
                    ftStatus = FT260_I2CMaster_Read(ft260Handle, I2CAddr, FT260_I2C_FLAG.FT260_I2C_START_AND_STOP,ref readData[0], len, ref readLength, 5000);
                    Console.WriteLine("FT260_I2C_Read  ftStatus: {0}  Read Length: {1}", ftStatus, readLength);    // ftStatus = 0 is FT260_OK
                    for (UInt32 i = 0; i < len; i++)
                    {
                        Console.Write("{0:X2} ", readData[i]);
                        if (i % 16 == 15)
                            Console.WriteLine("");
                    }
                    Console.WriteLine("");
                }
                else if (input == "2")
                {
                    Console.WriteLine("Write the content and press enter");
                    string lenStr = Console.ReadLine();
                    byte len = 0;
                    UInt32 writeLength = 0;
                    byte[] data;
                    if (byte.TryParse(lenStr, System.Globalization.NumberStyles.Number, null, out len))
                    {
                        Console.WriteLine("set read length = {0}", len);
                        if ((len < 1) || (len > 60))
                        {
                            Console.WriteLine("Length format error, 1~60");
                            continue;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Length format error, 1~60");
                        continue;
                    }
                    data = new byte[len];
                    for (UInt32 i = 0; i < len; i++)
                        data[i] = (byte)i;
                    ftStatus = FT260_I2CMaster_Write(ft260Handle, I2CAddr, FT260_I2C_FLAG.FT260_I2C_START_AND_STOP, ref data[0], len, ref writeLength);
                    Console.WriteLine("FT260_I2C_Write  ftStatus: {0}  Write Length: {1}", ftStatus, writeLength);
                }
                else if (input == "3")
                {
                    ftStatus = FT260_I2CMaster_Reset(ft260Handle);
                    Console.WriteLine("FT260_I2C_Reset  ftStatus: {0}", ftStatus);
                }
                else if (input == "4")
                {
                    /* I2C Master Controller Status (I2Cstauts variable)
                     *   bit 0 = controller busy: all other status bits invalid
                     *   bit 1 = error condition
                     *   bit 2 = slave address was not acknowledged during last operation
                     *   bit 3 = data not acknowledged during last operation
                     *   bit 4 = arbitration lost during last operation
                     *   bit 5 = controller idle
                     *   bit 6 = bus busy
                     */
                    byte I2Cstauts = 0;
                    ftStatus = FT260_I2CMaster_GetStatus(ft260Handle, ref I2Cstauts);
                    if (ftStatus == FT260_STATUS.FT260_OK)
                    {
                        PrintI2CStatus(I2Cstauts);
                    }
                    else
                    {
                        Console.WriteLine("Error FT260_I2C_GetStatus  ftStatus: {0}, I2Cstauts: 0x{1:x}", ftStatus, I2Cstauts);
                    }
                }
                else if (input == "5")
                {
                    Console.WriteLine("Read content from EEPROM");
                    Console.WriteLine("input the read addr (hex format), do not input 0x");
                    string addrStr = Console.ReadLine();
                    byte addr = 0;
                    if (addrStr.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
                    {
                        addrStr = addrStr.Substring(2); // remove "0x"
                    }
                    if (byte.TryParse(addrStr, System.Globalization.NumberStyles.HexNumber, null, out addr))
                    {
                        Console.WriteLine("set read addr = 0x{0}", addr);
                    }
                    else
                    {
                        Console.WriteLine("Addr format error, 00~FF");
                        continue;
                    }
                    Console.WriteLine("input the read size (dec format)");
                    string lenStr = Console.ReadLine();
                    UInt32 len = 0;
                    byte[] readData;
                    UInt32 writeLength = 0;
                    UInt32 readLength = 0;
                    byte I2Cstauts = 0;
                    if (UInt32.TryParse(lenStr, System.Globalization.NumberStyles.Number, null, out len))
                    {
                        Console.WriteLine("set read length = {0}", len);
                        if ((len < 1) || (len > 256))
                        {
                            Console.WriteLine("Length format error, 1~256");
                            continue;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Length format error, 1~256");
                        continue;
                    }
                    readData = new byte[len];
                    ftStatus = FT260_I2CMaster_WriteAndMonitorStatus(ft260Handle, I2CAddr, FT260_I2C_FLAG.FT260_I2C_START, ref addr, 1, ref writeLength, ref I2Cstauts);
                    if (ftStatus != FT260_STATUS.FT260_OK)
                    {
                        PrintI2CStatus(I2Cstauts);
                    }
                    ftStatus = FT260_I2CMaster_ReadAndMonitorStatus(ft260Handle, I2CAddr, FT260_I2C_FLAG.FT260_I2C_REPEATED_START | FT260_I2C_FLAG.FT260_I2C_STOP, ref readData[0], len, ref readLength, ref I2Cstauts, 5000);
                    FT260_I2CMaster_GetStatus(ft260Handle, ref I2Cstauts);
                    if (ftStatus != FT260_STATUS.FT260_OK)
                    {
                        PrintI2CStatus(I2Cstauts);
                    }
                    else
                    {
                        for (UInt32 i = 0; i < len; i++)
                        {
                            Console.Write("{0:X2} ", readData[i]);
                            if (i % 16 == 15)
                                Console.WriteLine("");
                        }
                        Console.WriteLine("");
                    }
                }                
                else if (input == "6")
                {
                    Console.WriteLine("Quit");
                    break;
                }
                else
                {
                    if (input == "")
                        Console.WriteLine("input is null");
                    else
                        Console.WriteLine("unknow input : {0}", input);
                }
            }
        }

        static void Main(string[] args)
        {
            FT260_STATUS ftStatus = FT260_STATUS.FT260_OTHER_ERROR;
            IntPtr ft260Handle = new IntPtr(-1);
            UInt32 devNum = 0;
            UInt16 VID = 0x0403;
            UInt16 PID = 0x6030;

            // Show all HID device path
            ListAllDevicePaths();
            FT260_CreateDeviceList(ref devNum);
            if (devNum < 1)
            {
                return;
            }
                        
            // Open device by index
            ftStatus = FT260_OpenByVidPid(VID, PID, 0, ref ft260Handle);
            if (FT260_STATUS.FT260_OK != ftStatus)
            {
                Console.WriteLine("Open device Failed, status: {0}", ftStatus);
                return;
            }
            else
            {
                Console.WriteLine("Open device OK");
            }

            // 1. Get Start
            Console.WriteLine("\n----TEST Get Start----");
            TestGetStart(ft260Handle);            

            // 2. I2C Test
            Console.WriteLine("\n----TEST I2C----");
            TestI2C(ft260Handle);
            Console.ReadKey();
        }
    }
}
